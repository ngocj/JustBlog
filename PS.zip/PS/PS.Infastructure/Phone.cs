﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PS.Infastructure
{
    public class Phone : Product
    {
        public string Brand {  get; set; }
        public int Storage {  get; set; }


        public override void DisplayInfo()
        {
            Console.WriteLine("ProductId: " + ProductId + " - " +
                              "ProductName: " + ProductName + " - " +
                              "Price: " + Price + " - " +
                              "Brand: " + Brand + " - " +
                              "Storage: " + Storage);
        }
    }
}
