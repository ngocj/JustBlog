﻿// See https://aka.ms/new-console-template for more information
using PS.Service;
using System.Text;

while (true)
{
    Console.OutputEncoding = Encoding.Unicode;
    Console.WriteLine("Store management");
    Console.WriteLine("1. Input phone");
    Console.WriteLine("2. Show all phones");
    Console.WriteLine("3. Find by name: ");
    Console.WriteLine("4. Exit");
    Console.Write("Choose: ");

    string choose = Console.ReadLine();

    switch (choose)
    {
        case "1":
            Store.InputProduct();
            break;
        case "2":
            Store.DisplayAllProducts();
            break;
        case "3":
            Console.WriteLine("Input name to find: ");
            string name = Console.ReadLine();
            Store.FindProductByName(name);
            break;
        case "4":
            Console.WriteLine("Exit Program");
            return;
        default:
            Console.WriteLine("Erros, pls choose another!!!");
            Console.ReadKey();
            break;
    }
}