﻿using PS.Infastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PS.Service
{
    public class Store
    {
        public static List<Product> products = new List<Product>();

        public static int GenId()
        {
            int id = 1;
            if (products.Count > 0)
            {
                id = products.Last().ProductId + 1;
            }
            return id;
        }

        public static void InputProduct()
        {
            Phone product = new Phone();
            product.ProductId = GenId();
            Console.WriteLine("Input product name: ");
            product.ProductName = Console.ReadLine();
            Console.WriteLine("Input price: ");
            double Price = double.Parse(Console.ReadLine());
            while (Price <= 0)
            {
                Console.WriteLine("ReInput price: ");
                Price = double.Parse(Console.ReadLine());
            }
            product.Price = Price;
            Console.WriteLine("Input brand");
            product.Brand = Console.ReadLine();
            Console.WriteLine("Input Storage");
            int Storage = int.Parse(Console.ReadLine());
            while (Storage <= 0)
            {
                Console.WriteLine("ReInput Storage");
                Storage = int.Parse(Console.ReadLine());
            }
            product.Storage = Storage;
            AddProduct(product);
        }

        public static void AddProduct(Product product)
        {
            products.Add(product);
        }

        public static void DisplayAllProducts()
        {
            foreach (Product product in products)
            {
                product.DisplayInfo();
            }
        }

        public static void FindProductByName(string name)
        {
            var product = products.Where(x => x.ProductName.Contains(name)).ToList();
            if (product.Count() > 0)
            {
                foreach (var item in product)
                {
                    item.DisplayInfo();
                }
            }
            else
            {
                Console.WriteLine("No product!");
            } 
        }
    }
}
